# FxEditor v0.3
Open in Android Studio (it generates the Gradle wrapper), then Run.

## Adding an effect (no Kotlin needed)
Add an `<effect>` to any file in `app/src/main/assets/effects/`. Param types:
float, angle, point ("x,y", 0..1), color ("#RRGGBB"), enum (options="A,B"), bool.
Each param `id` becomes `uniform ... u_<id>` automatically (float/angle/enum/bool = float,
point = vec2, color = vec4). Write `vec4 fx(vec2 uv)`; you also get uTex, uRes, uTime,
and helpers hash, hash2, vnoise, fbm, luma. Effects are written from scratch (no Alight code).

## Architecture
Anim.kt (easing + keyframes) / Params.kt / Effects.kt (XML loader, Layer) /
Shaders.kt (shader builder + blend/composite) / FxRenderer.kt / MainActivity.kt

## Importing Alight Motion scenes (Import XML button)
Reads <scene> XML: canvas size, shape/text layers, transform (location px, scale, rotation deg,
opacity), keyframes (t normalized to the layer's start/end window), cubicBezier/linear easing,
#AARRGGBB colors, and effect <property> values. Effects are mapped to OUR effects through
assets/effect_map.xml (only shake2 -> auto_shake is mapped; add more). Unmapped effects, groups,
anchors and unsupported layer types are skipped and listed in a dialog.
Not supported: media/video layers, drawings, blend-mode ints, anchor, group transforms.
Assumptions to verify: rotation sign, shape placeholder size (400px), shake mag px->uv scale.
Try examples/sample_scene.xml.
