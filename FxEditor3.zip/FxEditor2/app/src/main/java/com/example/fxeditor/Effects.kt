package com.example.fxeditor

import android.content.Context
import android.graphics.Bitmap
import org.w3c.dom.Element
import java.util.concurrent.CopyOnWriteArrayList
import javax.xml.parsers.DocumentBuilderFactory

class Layer(
    val bitmap: Bitmap, val name: String,
    var start: Float = 0f, var end: Float = Float.MAX_VALUE,   // visibility window, seconds
    val fitToCanvas: Boolean = true                             // false = bitmap pixels map 1:1 to canvas px
) {
    val transform = EffectInstance(Effects.TRANSFORM)
    val effects = CopyOnWriteArrayList<EffectInstance>()
}

object Effects {
    /** Order must match blendMode() in Shaders.COMPOSITE_FRAG */
    val BLEND_NAMES = listOf(
        "Normal", "Multiply", "Screen", "Overlay", "Darken", "Lighten", "Color Dodge",
        "Color Burn", "Hard Light", "Soft Light", "Difference", "Exclusion", "Add", "Subtract"
    )

    val TRANSFORM = EffectDef("transform", "Transform", "", listOf(
        ParamDef("pos", "Position", PType.POINT, 0f, 1f, floatArrayOf(0.5f, 0.5f), emptyList()),
        ParamDef("scale", "Scale", PType.FLOAT, 0.05f, 4f, floatArrayOf(1f), emptyList()),
        ParamDef("rot", "Rotation", PType.ANGLE, -6.2832f, 6.2832f, floatArrayOf(0f), emptyList()),
        ParamDef("opacity", "Opacity", PType.FLOAT, 0f, 1f, floatArrayOf(1f), emptyList()),
        ParamDef("blend", "Blend mode", PType.ENUM, 0f, 0f, floatArrayOf(0f), BLEND_NAMES)
    ), null)

    val IDENTITY = EffectDef("identity", "Identity", "", emptyList(),
        "vec4 fx(vec2 uv){ return texture(uTex, uv); }")

    var all: List<EffectDef> = emptyList(); private set

    fun parseColor(s: String): FloatArray {
        val h = s.trim().removePrefix("#"); val v = h.toLong(16)
        val r = ((v shr 16) and 255) / 255f; val g = ((v shr 8) and 255) / 255f; val b = (v and 255) / 255f
        val a = if (h.length == 8) ((v shr 24) and 255) / 255f else 1f
        return floatArrayOf(r, g, b, a)
    }

    /** Loads every assets/effects/*.xml. Adding a new effect = dropping in a new <effect> element. */
    fun load(ctx: Context) {
        val db = DocumentBuilderFactory.newInstance().newDocumentBuilder()
        val out = ArrayList<EffectDef>()
        for (f in (ctx.assets.list("effects") ?: emptyArray()).sorted()) {
            if (!f.endsWith(".xml")) continue
            val doc = ctx.assets.open("effects/$f").use { db.parse(it) }
            val es = doc.getElementsByTagName("effect")
            for (i in 0 until es.length) {
                val e = es.item(i) as Element
                val ps = e.getElementsByTagName("param")
                val params = (0 until ps.length).map { j ->
                    val p = ps.item(j) as Element
                    val type = when (p.getAttribute("type")) {
                        "point" -> PType.POINT; "color" -> PType.COLOR; "angle" -> PType.ANGLE
                        "enum" -> PType.ENUM; "bool" -> PType.BOOL; else -> PType.FLOAT
                    }
                    val d = p.getAttribute("default")
                    val def = when (type) {
                        PType.POINT -> d.split(",").map { it.trim().toFloat() }.toFloatArray()
                        PType.COLOR -> parseColor(d)
                        else -> floatArrayOf(d.ifEmpty { "0" }.toFloat())
                    }
                    val opts = p.getAttribute("options").let { if (it.isEmpty()) emptyList() else it.split(",") }
                    ParamDef(p.getAttribute("id"), p.getAttribute("name"), type,
                        p.getAttribute("min").toFloatOrNull() ?: 0f,
                        p.getAttribute("max").toFloatOrNull() ?: 1f, def, opts)
                }
                val sh = e.getElementsByTagName("shader").item(0)?.textContent ?: continue
                out.add(EffectDef(e.getAttribute("id"), e.getAttribute("name"), e.getAttribute("category"), params, sh))
            }
        }
        all = out
    }
}
