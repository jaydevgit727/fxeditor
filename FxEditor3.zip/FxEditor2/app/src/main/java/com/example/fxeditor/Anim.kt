package com.example.fxeditor

import kotlin.math.*

sealed class Easing(val label: String) {
    abstract fun f(x: Float): Float

    object Linear : Easing("Linear") { override fun f(x: Float) = x }
    object Hold : Easing("Hold") { override fun f(x: Float) = if (x < 1f) 0f else 1f }
    object Bounce : Easing("Bounce") {
        override fun f(x: Float): Float {
            val n = 7.5625f; val d = 2.75f
            return when {
                x < 1 / d -> n * x * x
                x < 2 / d -> { val t = x - 1.5f / d; n * t * t + 0.75f }
                x < 2.5 / d -> { val t = x - 2.25f / d; n * t * t + 0.9375f }
                else -> { val t = x - 2.625f / d; n * t * t + 0.984375f }
            }
        }
    }
    object Elastic : Easing("Elastic") {
        override fun f(x: Float): Float {
            if (x <= 0f) return 0f; if (x >= 1f) return 1f
            return (2.0.pow(-10.0 * x) * sin((x * 10.0 - 0.75) * (2.0 * PI / 3.0)) + 1.0).toFloat()
        }
    }
    class Bezier(label: String, val x1: Float, val y1: Float, val x2: Float, val y2: Float) : Easing(label) {
        private fun bez(a: Float, b: Float, t: Float): Float { val u = 1 - t; return 3 * u * u * t * a + 3 * u * t * t * b + t * t * t }
        override fun f(x: Float): Float {
            var lo = 0f; var hi = 1f
            repeat(24) { val m = (lo + hi) / 2; if (bez(x1, x2, m) < x) lo = m else hi = m }
            return bez(y1, y2, (lo + hi) / 2)
        }
    }

    companion object {
        val presets: List<Easing> = listOf(
            Linear, Hold,
            Bezier("Ease In", 0.42f, 0f, 1f, 1f),
            Bezier("Ease Out", 0f, 0f, 0.58f, 1f),
            Bezier("Ease In-Out", 0.42f, 0f, 0.58f, 1f),
            Bezier("Overshoot", 0.34f, 1.56f, 0.64f, 1f),
            Bounce, Elastic
        )
    }
}

class Key(val t: Float, val v: Float, val ease: Easing)

class Track(def: Float) {
    private val keys = ArrayList<Key>().apply { add(Key(0f, def, Easing.Linear)) }

    @Synchronized fun set(t: Float, v: Float, e: Easing) {
        keys.removeAll { abs(it.t - t) < 1e-3f }
        keys.add(Key(t, v, e)); keys.sortBy { it.t }
    }
    @Synchronized fun load(list: List<Key>) {
        keys.clear(); keys.addAll(list.sortedBy { it.t }); if (keys.isEmpty()) keys.add(Key(0f, 0f, Easing.Linear))
    }
    @Synchronized fun reset(v: Float) { keys.clear(); keys.add(Key(0f, v, Easing.Linear)) }
    @Synchronized fun at(t: Float): Float {
        if (t <= keys.first().t) return keys.first().v
        if (t >= keys.last().t) return keys.last().v
        var i = 0
        while (i < keys.size - 2 && keys[i + 1].t <= t) i++
        val a = keys[i]; val b = keys[i + 1]
        return a.v + (b.v - a.v) * a.ease.f((t - a.t) / (b.t - a.t))
    }
}

class ParamAnim(val def: ParamDef) {
    val tracks = Array(def.n) { Track(def.def[it]) }
    fun value(t: Float) = FloatArray(def.n) { tracks[it].at(t) }
}

class EffectInstance(val def: EffectDef) {
    val anims: Map<String, ParamAnim> = def.params.associate { it.id to ParamAnim(it) }
    @Volatile var enabled = true
}
