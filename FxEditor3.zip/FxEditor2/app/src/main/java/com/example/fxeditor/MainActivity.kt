package com.example.fxeditor

import android.animation.ValueAnimator
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val layers = CopyOnWriteArrayList<Layer>()
    private lateinit var renderer: FxRenderer
    private lateinit var gl: GLSurfaceView
    private lateinit var layerSp: Spinner
    private lateinit var targetSp: Spinner
    private lateinit var easeSp: Spinner
    private lateinit var timeBar: SeekBar
    private lateinit var keyMode: CheckBox
    private lateinit var paramBox: LinearLayout
    private var selLayer = -1
    private var target: EffectInstance? = null
    private var duration = 10f
    private var anim: ValueAnimator? = null

    private fun t() = timeBar.progress / 1000f * duration
    private fun curLayer() = layers.getOrNull(selLayer)

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        val bmp = loadBitmap(uri) ?: return@registerForActivityResult
        layers.add(Layer(bmp, "Layer ${layers.size + 1}"))
        selLayer = layers.size - 1
        refreshLayers(); gl.requestRender()
    }

    private val importPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        try {
            val r = contentResolver.openInputStream(uri)!!.use { SceneImport.parse(this, it) }
            layers.clear(); layers.addAll(r.layers)
            renderer.setCanvas(r.width, r.height); duration = r.durationSec
            selLayer = layers.size - 1; refreshLayers(); gl.requestRender()
            AlertDialog.Builder(this).setTitle("Imported " + r.layers.size + " layers")
                .setMessage(if (r.warnings.isEmpty()) "No warnings" else r.warnings.distinct().joinToString("\n"))
                .setPositiveButton("OK", null).show()
        } catch (e: Exception) { Toast.makeText(this, "Import failed: " + e.message, Toast.LENGTH_LONG).show() }
    }

    private fun loadBitmap(uri: Uri): android.graphics.Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1; while (max(o.outWidth, o.outHeight) / s > 2048) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    private fun Spinner.setItems(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
        adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, items)
        if (sel in items.indices) setSelection(sel, false)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun refreshLayers() {
        layerSp.setItems(layers.map { it.name }, selLayer) { if (it != selLayer) { selLayer = it; refreshTargets(0) } }
        refreshTargets(0)
    }

    private fun refreshTargets(sel: Int) {
        val l = curLayer()
        if (l == null) { targetSp.adapter = null; target = null; buildParams(); return }
        val list = listOf(l.transform) + l.effects
        targetSp.setItems(list.map { it.def.name }, sel) { i ->
            target = (listOf(l.transform) + l.effects).getOrNull(i); buildParams()
        }
        target = list.getOrNull(sel); buildParams()
    }

    private fun write(a: ParamAnim, comp: Int, v: Float) {
        if (keyMode.isChecked) a.tracks[comp].set(t(), v, Easing.presets[easeSp.selectedItemPosition])
        else a.tracks[comp].reset(v)
        gl.requestRender()
    }

    private fun addSlider(label: String, a: ParamAnim, comp: Int, mn: Float, mx: Float) {
        val tv = TextView(this); val sb = SeekBar(this).apply { max = 1000 }
        val v = a.tracks[comp].at(t())
        fun fmt(x: Float) = label + ": " + "%.3f".format(x)
        tv.text = fmt(v); sb.progress = ((v - mn) / (mx - mn) * 1000).toInt()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                if (!user) return
                val x = mn + (mx - mn) * p / 1000f; write(a, comp, x); tv.text = fmt(x)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        paramBox.addView(tv); paramBox.addView(sb)
    }

    private fun buildParams() {
        paramBox.removeAllViews()
        val inst = target ?: return
        for (pd in inst.def.params) {
            val a = inst.anims[pd.id]!!
            when (pd.type) {
                PType.ENUM -> {
                    paramBox.addView(TextView(this).apply { text = pd.name })
                    paramBox.addView(Spinner(this).apply {
                        setItems(pd.options, a.tracks[0].at(t()).roundToInt()) { write(a, 0, it.toFloat()) }
                    })
                }
                PType.BOOL -> paramBox.addView(CheckBox(this).apply {
                    text = pd.name; isChecked = a.tracks[0].at(t()) > 0.5f
                    setOnCheckedChangeListener { _, c -> write(a, 0, if (c) 1f else 0f) }
                })
                PType.POINT -> for (i in 0..1) addSlider(pd.name + if (i == 0) " X" else " Y", a, i, 0f, 1f)
                PType.COLOR -> for (i in 0..2) addSlider(pd.name + " " + "RGB"[i], a, i, 0f, 1f)
                else -> addSlider(pd.name, a, 0, pd.min, pd.max)
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Effects.load(this)
        renderer = FxRenderer(layers)
        gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3); setRenderer(renderer); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        }
        layerSp = Spinner(this); targetSp = Spinner(this)
        val fxSp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                Effects.all.map { it.category + " · " + it.name })
        }
        easeSp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Easing.presets.map { it.label })
        }
        keyMode = CheckBox(this).apply { text = "Keyframe mode (new keys use easing →)" }
        timeBar = SeekBar(this).apply { max = 1000 }
        paramBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        timeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { renderer.time = t(); gl.requestRender() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { buildParams() }
        })

        fun btn(txt: String, f: () -> Unit) = Button(this).apply { text = txt; setOnClickListener { f() } }
        val addImg = btn("+ Image") { picker.launch("image/*") }
        val delLayer = btn("Del layer") {
            curLayer()?.let { layers.remove(it) }; selLayer = layers.size - 1; refreshLayers(); gl.requestRender()
        }
        val imp = btn("Import XML") { importPicker.launch("*/*") }
        val addFx = btn("+ Effect") {
            val l = curLayer() ?: return@btn
            l.effects.add(EffectInstance(Effects.all[fxSp.selectedItemPosition]))
            refreshTargets(l.effects.size); gl.requestRender()
        }
        val delFx = btn("Del effect") {
            val l = curLayer() ?: return@btn; val tg = target ?: return@btn
            if (tg !== l.transform) { l.effects.remove(tg); refreshTargets(0); gl.requestRender() }
        }
        val play = btn("Play") {}
        play.setOnClickListener {
            if (anim?.isRunning == true) { anim?.cancel(); play.text = "Play" } else {
                play.text = "Stop"
                anim = ValueAnimator.ofInt(0, 1000).apply {
                    duration = (duration * 1000).toLong(); interpolator = LinearInterpolator()
                    repeatCount = ValueAnimator.INFINITE
                    addUpdateListener { timeBar.progress = it.animatedValue as Int }; start()
                }
            }
        }

        fun row(vararg v: View) = LinearLayout(this).apply {
            v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 16)
            addView(row(addImg, layerSp, delLayer))
            addView(row(fxSp, addFx, imp))
            addView(row(targetSp, delFx))
            addView(timeBar); addView(row(play, easeSp)); addView(keyMode)
            addView(paramBox)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(gl, LinearLayout.LayoutParams(-1, 0, 0.42f))
            addView(ScrollView(this@MainActivity).apply { addView(panel) }, LinearLayout.LayoutParams(-1, 0, 0.58f))
        }
        setContentView(root)
    }

    override fun onResume() { super.onResume(); gl.onResume() }
    override fun onPause() { super.onPause(); gl.onPause() }
}
