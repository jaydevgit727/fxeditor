package com.example.fxeditor

enum class PType { FLOAT, ANGLE, POINT, COLOR, ENUM, BOOL }

class ParamDef(
    val id: String, val name: String, val type: PType,
    val min: Float, val max: Float, val def: FloatArray, val options: List<String>
) {
    /** number of float components (uniform size) */
    val n: Int get() = when (type) { PType.POINT -> 2; PType.COLOR -> 4; else -> 1 }
    fun compMin(i: Int) = if (type == PType.POINT || type == PType.COLOR) 0f else min
    fun compMax(i: Int) = if (type == PType.POINT || type == PType.COLOR) 1f else max
}

/** shader == null means built-in (e.g. Transform). Shader body must define: vec4 fx(vec2 uv) */
class EffectDef(
    val id: String, val name: String, val category: String,
    val params: List<ParamDef>, val shader: String?
)
