package com.example.fxeditor

object Shaders {
    val VERT = listOf(
        "#version 300 es",
        "out vec2 vUv;",
        "void main(){",
        "  vec2 p = vec2(float((gl_VertexID<<1)&2), float(gl_VertexID&2));",
        "  vUv = p; gl_Position = vec4(p*2.0-1.0, 0.0, 1.0);",
        "}"
    ).joinToString("\n")

    /** Helpers available to every effect shader. */
    private const val PRELUDE = """
float hash(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }
vec2 hash2(vec2 p){ return vec2(hash(p), hash(p+vec2(37.1,17.3))); }
float vnoise(vec2 p){
  vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
  return mix(mix(hash(i),hash(i+vec2(1.0,0.0)),f.x), mix(hash(i+vec2(0.0,1.0)),hash(i+vec2(1.0,1.0)),f.x), f.y);
}
float fbm(vec2 p){ float v=0.0,a=0.5; for(int i=0;i<5;i++){ v+=a*vnoise(p); p*=2.0; a*=0.5; } return v; }
float luma(vec3 c){ return dot(c, vec3(0.299,0.587,0.114)); }
"""

    /** Builds the fragment shader. Each param id becomes `uniform ... u_<id>` automatically. */
    fun fragment(d: EffectDef): String {
        val sb = StringBuilder()
        sb.append("#version 300 es\nprecision highp float;\n")
        sb.append("uniform sampler2D uTex;\nuniform vec2 uRes;\nuniform float uTime;\n")
        for (p in d.params) sb.append("uniform ").append(
            when (p.n) { 1 -> "float"; 2 -> "vec2"; else -> "vec4" }).append(" u_").append(p.id).append(";\n")
        sb.append("in vec2 vUv;\nout vec4 o;\n").append(PRELUDE).append(d.shader).append("\nvoid main(){ o = fx(vUv); }\n")
        return sb.toString()
    }

    val COMPOSITE_FRAG = """#version 300 es
precision highp float;
uniform sampler2D uBack, uLayer;
uniform vec2 uCanvas, uLayerSize, uPos;
uniform float uScale, uRot, uOpacity;
uniform int uBlend;
in vec2 vUv; out vec4 o;

vec3 blendMode(int m, vec3 b, vec3 s){
  if(m==1) return b*s;
  if(m==2) return 1.0-(1.0-b)*(1.0-s);
  if(m==3) return mix(2.0*b*s, 1.0-2.0*(1.0-b)*(1.0-s), step(0.5,b));
  if(m==4) return min(b,s);
  if(m==5) return max(b,s);
  if(m==6) return min(b/max(1.0-s,0.001), vec3(1.0));
  if(m==7) return 1.0-min((1.0-b)/max(s,0.001), vec3(1.0));
  if(m==8) return mix(2.0*b*s, 1.0-2.0*(1.0-b)*(1.0-s), step(0.5,s));
  if(m==9) return mix(2.0*b*s+b*b*(1.0-2.0*s), sqrt(b)*(2.0*s-1.0)+2.0*b*(1.0-s), step(0.5,s));
  if(m==10) return abs(b-s);
  if(m==11) return b+s-2.0*b*s;
  if(m==12) return min(b+s, vec3(1.0));
  if(m==13) return max(b-s, vec3(0.0));
  return s;
}

void main(){
  vec4 b = texture(uBack, vUv);
  vec2 p = (vUv - uPos) * uCanvas;
  float cs = cos(uRot), sn = sin(uRot);
  p = vec2(p.x*cs + p.y*sn, -p.x*sn + p.y*cs) / uScale;
  vec2 l = p / uLayerSize + 0.5;
  if(l.x<0.0 || l.x>1.0 || l.y<0.0 || l.y>1.0){ o = b; return; }
  vec4 s = texture(uLayer, l);
  vec3 r = blendMode(uBlend, b.rgb, s.rgb);
  o = vec4(mix(b.rgb, r, s.a*uOpacity), 1.0);
}
"""
}
