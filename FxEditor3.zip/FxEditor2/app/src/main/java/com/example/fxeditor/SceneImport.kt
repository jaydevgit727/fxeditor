package com.example.fxeditor

import android.content.Context
import android.graphics.*
import org.w3c.dom.Element
import java.io.InputStream
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.PI
import kotlin.math.max

class ImportResult(
    val layers: List<Layer>, val width: Int, val height: Int,
    val durationSec: Float, val warnings: List<String>
)

/**
 * Imports Alight Motion <scene> project XML (structure documented in the community schema repo).
 * Reads layer structure, transforms, keyframes, easing and effect property values.
 * Effects are NOT loaded from Alight: each Alight effect id is mapped to one of OUR effects
 * through assets/effect_map.xml. Unmapped effects are skipped and reported.
 */
object SceneImport {
    private class EffMap(val ours: EffectDef, val params: Map<String, Pair<ParamDef, Float>>)

    private fun kids(e: Element, tag: String): List<Element> {
        val out = ArrayList<Element>(); val n = e.childNodes
        for (i in 0 until n.length) { val c = n.item(i); if (c is Element && c.tagName == tag) out.add(c) }
        return out
    }
    private fun elems(e: Element): List<Element> {
        val out = ArrayList<Element>(); val n = e.childNodes
        for (i in 0 until n.length) { val c = n.item(i); if (c is Element) out.add(c) }
        return out
    }

    private fun parseVal(type: String, s: String): FloatArray = when (type) {
        "color" -> Effects.parseColor(s)                               // #AARRGGBB
        "bool" -> floatArrayOf(if (s == "true" || s == "1") 1f else 0f)
        else -> s.split(",").map { it.trim().toFloat() }.toFloatArray() // float,int,vec2,size,...
    }

    private fun easing(e: String): Easing {
        val p = e.trim().split(Regex("\\s+"))
        if (p.size == 5 && p[0] == "cubicBezier")
            return Easing.Bezier("Custom", p[1].toFloat(), p[2].toFloat(), p[3].toFloat(), p[4].toFloat())
        return Easing.Linear // "linear" or omitted
    }

    /** Writes a <property>/<location>/... element (static `value` or <kf> children) into a ParamAnim. */
    private fun load(el: Element, type: String, anim: ParamAnim, t0: Float, t1: Float, conv: (FloatArray) -> FloatArray) {
        fun comp(c: FloatArray, i: Int) = if (i < c.size) c[i] else anim.def.def[i]
        val kfs = kids(el, "kf")
        if (kfs.isEmpty()) {
            val v = el.getAttribute("value"); if (v.isEmpty()) return
            val c = conv(parseVal(type, v))
            for (i in anim.tracks.indices) anim.tracks[i].reset(comp(c, i))
            return
        }
        val lists = Array(anim.tracks.size) { ArrayList<Key>() }
        for (k in kfs) {
            val tt = t0 + k.getAttribute("t").toFloat() * (t1 - t0)  // t is normalized to layer window
            val c = conv(parseVal(type, k.getAttribute("v"))); val ez = easing(k.getAttribute("e"))
            for (i in lists.indices) lists[i].add(Key(tt, comp(c, i), ez))
        }
        for (i in lists.indices) anim.tracks[i].load(lists[i])
    }

    private fun loadMap(ctx: Context): Map<String, EffMap> {
        val out = HashMap<String, EffMap>()
        val doc = ctx.assets.open("effect_map.xml").use { DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(it) }
        val es = doc.getElementsByTagName("effect")
        for (i in 0 until es.length) {
            val e = es.item(i) as Element
            val def = Effects.all.firstOrNull { it.id == e.getAttribute("ours") } ?: continue
            val pm = HashMap<String, Pair<ParamDef, Float>>()
            for (p in kids(e, "param")) {
                val pd = def.params.firstOrNull { it.id == p.getAttribute("ours") } ?: continue
                pm[p.getAttribute("alight")] = pd to (p.getAttribute("scale").toFloatOrNull() ?: 1f)
            }
            out[e.getAttribute("alight")] = EffMap(def, pm)
        }
        return out
    }

    // ---- placeholder visuals (media layers aren't supported: tag/bundle format not documented) ----
    private fun shapeBitmap(kind: String, color: Int): Bitmap {
        val px = 400; val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val c = Canvas(b)
        if (kind == ".circle") c.drawOval(RectF(0f, 0f, px.toFloat(), px.toFloat()), p)
        else c.drawRect(0f, 0f, px.toFloat(), px.toFloat(), p)
        return b
    }
    private fun textBitmap(text: String, size: Float, color: Int): Bitmap {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color }
        val lines = text.split("\n"); val lh = p.fontSpacing
        val w = max(4, lines.maxOf { p.measureText(it) }.toInt() + 4); val h = max(4, (lh * lines.size).toInt() + 4)
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(b)
        lines.forEachIndexed { i, s -> c.drawText(s, 2f, lh * (i + 1) - p.descent(), p) }
        return b
    }

    fun parse(ctx: Context, xml: InputStream): ImportResult {
        val map = loadMap(ctx)
        val root = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xml).documentElement
        require(root.tagName == "scene") { "Not an Alight <scene> file" }
        val W = root.getAttribute("width").toIntOrNull() ?: 1280
        val H = root.getAttribute("height").toIntOrNull() ?: 720
        val totalMs = root.getAttribute("totalTime").toFloatOrNull() ?: 2000f
        val warn = ArrayList<String>(); val out = ArrayList<Layer>()

        fun build(el: Element): Layer? {
            val tag = el.tagName; val label = el.getAttribute("label").ifEmpty { tag }
            val t0 = (el.getAttribute("startTime").toFloatOrNull() ?: 0f) / 1000f
            var t1 = (el.getAttribute("endTime").toFloatOrNull() ?: totalMs) / 1000f
            if (t1 <= t0) t1 = t0 + 0.001f
            val fill = kids(el, "fillColor").firstOrNull()?.getAttribute("value")?.ifEmpty { null } ?: "#FFFFFFFF"
            val col = try { Color.parseColor(fill) } catch (e: Exception) { Color.WHITE }
            val bmp = when (tag) {
                "shape" -> { warn.add("Shape sizes aren't documented: '$label' drawn as a 400px placeholder"); shapeBitmap(el.getAttribute("s"), col) }
                "text" -> textBitmap(kids(el, "content").firstOrNull()?.textContent ?: "",
                    el.getAttribute("size").toFloatOrNull() ?: 48f, col)
                else -> return null
            }
            val layer = Layer(bmp, label, t0, t1, fitToCanvas = false)

            kids(el, "transform").firstOrNull()?.let { tr ->
                val a = layer.transform.anims
                kids(tr, "location").firstOrNull()?.let {   // px, origin top-left -> uv, origin bottom-left
                    load(it, "vec2", a["pos"]!!, t0, t1) { v -> floatArrayOf(v[0] / W, 1f - v[1] / H) } }
                kids(tr, "scale").firstOrNull()?.let {      // our scale is uniform: use x
                    load(it, "vec2", a["scale"]!!, t0, t1) { v -> floatArrayOf(v[0]) } }
                kids(tr, "rotation").firstOrNull()?.let {   // degrees (assumed clockwise) -> radians CCW
                    load(it, "float", a["rot"]!!, t0, t1) { v -> floatArrayOf(-v[0] * PI.toFloat() / 180f) } }
                kids(tr, "opacity").firstOrNull()?.let {
                    load(it, "float", a["opacity"]!!, t0, t1) { v -> v } }
                if (kids(tr, "anchor").isNotEmpty()) warn.add("Anchor point ignored on '$label'")
            }

            for (fx in kids(el, "effect")) {
                val id = fx.getAttribute("id"); val m = map[id]
                if (m == null) { warn.add("Skipped unmapped effect $id on '$label'"); continue }
                val inst = EffectInstance(m.ours)
                for (p in kids(fx, "property")) {
                    val (pd, scale) = m.params[p.getAttribute("name")] ?: continue
                    load(p, p.getAttribute("type").ifEmpty { "float" }, inst.anims[pd.id]!!, t0, t1) { v ->
                        if (pd.type == PType.COLOR) v else FloatArray(v.size) { v[it] * scale } }
                }
                layer.effects.add(inst)
            }
            return layer
        }

        fun walk(parent: Element) {
            for (c in elems(parent)) when (c.tagName) {
                "shape", "text" -> build(c)?.let { out.add(it) }
                "group" -> { warn.add("Group '${c.getAttribute("label")}' flattened (group transform ignored)"); walk(c) }
                "media", "bookmark", "property" -> {}
                else -> warn.add("Unsupported element <${c.tagName}> skipped")
            }
        }
        walk(root)
        val dur = out.maxOfOrNull { if (it.end == Float.MAX_VALUE) 0f else it.end } ?: 0f
        return ImportResult(out, W, H, max(dur, totalMs / 1000f).coerceIn(1f, 600f), warn)
    }
}
