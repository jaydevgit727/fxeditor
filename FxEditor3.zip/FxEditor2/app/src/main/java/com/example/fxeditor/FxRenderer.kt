package com.example.fxeditor

import android.graphics.Bitmap
import android.graphics.Matrix
import android.opengl.GLES30 as G
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.min
import kotlin.math.roundToInt

class FxRenderer(private val layers: List<Layer>) : GLSurfaceView.Renderer {
    @Volatile var time = 0f
    private var CW = 1280; private var CH = 720          // GL-thread only
    @Volatile private var reqW = 1280; @Volatile private var reqH = 720
    fun setCanvas(w: Int, h: Int) { reqW = w; reqH = h }

    private class LGL(val w: Int, val h: Int, val src: Int, val fbo: IntArray, val tex: IntArray)
    private val lgl = HashMap<Layer, LGL>()
    private val progs = HashMap<String, Int>()
    private val accFbo = IntArray(2); private val accTex = IntArray(2)
    private var sw = 1; private var sh = 1

    private fun shader(type: Int, src: String): Int {
        val s = G.glCreateShader(type); G.glShaderSource(s, src); G.glCompileShader(s)
        val ok = IntArray(1); G.glGetShaderiv(s, G.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException(G.glGetShaderInfoLog(s) + "\n" + src)
        return s
    }
    private fun program(key: String, frag: String) = progs.getOrPut(key) {
        val p = G.glCreateProgram()
        G.glAttachShader(p, shader(G.GL_VERTEX_SHADER, Shaders.VERT))
        G.glAttachShader(p, shader(G.GL_FRAGMENT_SHADER, frag))
        G.glLinkProgram(p); p
    }

    private fun newTex(w: Int, h: Int, bmp: Bitmap?): Int {
        val t = IntArray(1); G.glGenTextures(1, t, 0)
        G.glBindTexture(G.GL_TEXTURE_2D, t[0])
        if (bmp != null) GLUtils.texImage2D(G.GL_TEXTURE_2D, 0, bmp, 0)
        else G.glTexImage2D(G.GL_TEXTURE_2D, 0, G.GL_RGBA, w, h, 0, G.GL_RGBA, G.GL_UNSIGNED_BYTE, null)
        G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MIN_FILTER, G.GL_LINEAR)
        G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_MAG_FILTER, G.GL_LINEAR)
        G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_S, G.GL_CLAMP_TO_EDGE)
        G.glTexParameteri(G.GL_TEXTURE_2D, G.GL_TEXTURE_WRAP_T, G.GL_CLAMP_TO_EDGE)
        return t[0]
    }
    private fun newFbo(tex: Int): Int {
        val f = IntArray(1); G.glGenFramebuffers(1, f, 0)
        G.glBindFramebuffer(G.GL_FRAMEBUFFER, f[0])
        G.glFramebufferTexture2D(G.GL_FRAMEBUFFER, G.GL_COLOR_ATTACHMENT0, G.GL_TEXTURE_2D, tex, 0)
        return f[0]
    }

    private fun createLayerGL(l: Layer): LGL {
        val flip = Matrix().apply { preScale(1f, -1f) } // uv origin = bottom-left
        val b = Bitmap.createBitmap(l.bitmap, 0, 0, l.bitmap.width, l.bitmap.height, flip, false)
        val src = newTex(b.width, b.height, b)
        val tex = IntArray(2) { newTex(b.width, b.height, null) }
        val fbo = IntArray(2) { newFbo(tex[it]) }
        return LGL(b.width, b.height, src, fbo, tex)
    }

    private fun deleteLayerGL(g: LGL) {
        G.glDeleteTextures(1, intArrayOf(g.src), 0)
        G.glDeleteTextures(2, g.tex, 0); G.glDeleteFramebuffers(2, g.fbo, 0)
    }

    private fun allocAcc() {
        if (accTex[0] != 0) { G.glDeleteTextures(2, accTex, 0); G.glDeleteFramebuffers(2, accFbo, 0) }
        CW = reqW; CH = reqH
        for (i in 0..1) { accTex[i] = newTex(CW, CH, null); accFbo[i] = newFbo(accTex[i]) }
        G.glBindFramebuffer(G.GL_FRAMEBUFFER, 0)
    }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        progs.clear(); lgl.clear(); accTex.fill(0); allocAcc()
        G.glBindFramebuffer(G.GL_FRAMEBUFFER, 0)
        G.glClearColor(0.08f, 0.08f, 0.08f, 1f)
    }
    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { sw = w; sh = h }

    private fun drawEffect(inst: EffectInstance, input: Int, w: Int, h: Int) {
        val p = program(inst.def.id, Shaders.fragment(inst.def)); G.glUseProgram(p)
        G.glActiveTexture(G.GL_TEXTURE0); G.glBindTexture(G.GL_TEXTURE_2D, input)
        G.glUniform1i(G.glGetUniformLocation(p, "uTex"), 0)
        G.glUniform2f(G.glGetUniformLocation(p, "uRes"), w.toFloat(), h.toFloat())
        G.glUniform1f(G.glGetUniformLocation(p, "uTime"), time)
        for (pd in inst.def.params) {
            val v = inst.anims[pd.id]!!.value(time)
            val loc = G.glGetUniformLocation(p, "u_" + pd.id)
            when (pd.n) {
                1 -> G.glUniform1f(loc, v[0])
                2 -> G.glUniform2f(loc, v[0], v[1])
                else -> G.glUniform4f(loc, v[0], v[1], v[2], v[3])
            }
        }
        G.glDrawArrays(G.GL_TRIANGLES, 0, 3)
    }

    private fun composite(l: Layer, g: LGL, layerTex: Int, back: Int) {
        val p = program("composite", Shaders.COMPOSITE_FRAG); G.glUseProgram(p)
        G.glActiveTexture(G.GL_TEXTURE0); G.glBindTexture(G.GL_TEXTURE_2D, back)
        G.glActiveTexture(G.GL_TEXTURE1); G.glBindTexture(G.GL_TEXTURE_2D, layerTex)
        G.glUniform1i(G.glGetUniformLocation(p, "uBack"), 0)
        G.glUniform1i(G.glGetUniformLocation(p, "uLayer"), 1)
        val a = l.transform.anims
        val pos = a["pos"]!!.value(time)
        val fit = min(CW.toFloat() / g.w, CH.toFloat() / g.h)
        G.glUniform2f(G.glGetUniformLocation(p, "uCanvas"), CW.toFloat(), CH.toFloat())
        val k = if (l.fitToCanvas) fit else 1f
        G.glUniform2f(G.glGetUniformLocation(p, "uLayerSize"), g.w * k, g.h * k)
        G.glUniform2f(G.glGetUniformLocation(p, "uPos"), pos[0], pos[1])
        G.glUniform1f(G.glGetUniformLocation(p, "uScale"), a["scale"]!!.value(time)[0])
        G.glUniform1f(G.glGetUniformLocation(p, "uRot"), a["rot"]!!.value(time)[0])
        G.glUniform1f(G.glGetUniformLocation(p, "uOpacity"), a["opacity"]!!.value(time)[0])
        G.glUniform1i(G.glGetUniformLocation(p, "uBlend"), a["blend"]!!.value(time)[0].roundToInt())
        G.glDrawArrays(G.GL_TRIANGLES, 0, 3)
        G.glActiveTexture(G.GL_TEXTURE0)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (reqW != CW || reqH != CH) allocAcc()
        val live = layers.toList()
        lgl.keys.filter { it !in live }.forEach { deleteLayerGL(lgl.remove(it)!!) }

        G.glBindFramebuffer(G.GL_FRAMEBUFFER, accFbo[0]); G.glViewport(0, 0, CW, CH)
        G.glClearColor(0f, 0f, 0f, 1f); G.glClear(G.GL_COLOR_BUFFER_BIT)
        var cur = 0
        for (l in live) {
            if (time < l.start || time > l.end) continue
            val g = lgl.getOrPut(l) { createLayerGL(l) }
            var input = g.src; var d = 0
            for (fx in l.effects) {
                if (!fx.enabled) continue
                G.glBindFramebuffer(G.GL_FRAMEBUFFER, g.fbo[d]); G.glViewport(0, 0, g.w, g.h)
                drawEffect(fx, input, g.w, g.h); input = g.tex[d]; d = 1 - d
            }
            val dst = 1 - cur
            G.glBindFramebuffer(G.GL_FRAMEBUFFER, accFbo[dst]); G.glViewport(0, 0, CW, CH)
            composite(l, g, input, accTex[cur]); cur = dst
        }
        // aspect-fit canvas to screen
        G.glBindFramebuffer(G.GL_FRAMEBUFFER, 0)
        G.glViewport(0, 0, sw, sh); G.glClearColor(0.08f, 0.08f, 0.08f, 1f); G.glClear(G.GL_COLOR_BUFFER_BIT)
        val s = min(sw.toFloat() / CW, sh.toFloat() / CH)
        val vw = (CW * s).toInt(); val vh = (CH * s).toInt()
        G.glViewport((sw - vw) / 2, (sh - vh) / 2, vw, vh)
        drawEffect(EffectInstance(Effects.IDENTITY), accTex[cur], CW, CH)
    }
}
